/* *****************************************************************************
 *  Name: Anasthasia Manu
 *  Date: 19/04/2020
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private final boolean[][] sites;
    private final int n;
    private final int virtualTop;
    private final int virtualBottom;
    private int openSites = 0;
    private final WeightedQuickUnionUF uf;
    private final WeightedQuickUnionUF uf1;

    // creates n-by-n grid, with all sites initially blocked
    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        this.n = n;
        this.sites = new boolean[n][n];
        this.uf = new WeightedQuickUnionUF((n * n) + 2);
        this.uf1 = new WeightedQuickUnionUF((n * n) + 2);
        // use last two positions in uf array as placeholder for top/bottom
        this.virtualTop = 0;
        this.virtualBottom = n * n + 1;

        for (int i = 1;  i <= n; i++) {
            uf.union(virtualTop, i);
        }
        for (int i = (n * (n - 1)) + 1;  i <= (n * n); i++) {
            uf.union(virtualBottom, i);
        }


    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        row--;
        col--;
        checkBoundaries(row, col);
        if (isOpen(row, col)) {
            return;
        }
        openSites++;
        sites[row][col] = true;
        if (isOpen(row + 1, col)) {
            uf.union(getFlatMapId(row, col), getFlatMapId(row + 1, col));
            uf1.union(getFlatMapId(row, col), getFlatMapId(row + 1, col));
        }
        if (isOpen(row - 1, col)) {
            uf.union(getFlatMapId(row, col), getFlatMapId(row - 1, col));
            uf1.union(getFlatMapId(row, col), getFlatMapId(row - 1, col));
        }
        if (isOpen(row, col + 1)) {
            uf.union(getFlatMapId(row, col), getFlatMapId(row, col + 1));
            uf1.union(getFlatMapId(row, col), getFlatMapId(row, col + 1));
        }
        if (isOpen(row, col - 1)) {
            uf.union(getFlatMapId(row, col), getFlatMapId(row, col - 1));
            uf1.union(getFlatMapId(row, col), getFlatMapId(row, col - 1));
        }
        if (row == 0) {
            uf.union(getFlatMapId(row, col), virtualTop);
            uf1.union(getFlatMapId(row, col), virtualTop);
        }
        if (row == n -1) {
            uf.union(getFlatMapId(row, col), virtualBottom);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        try {
            checkBoundaries(row, col);
            return sites[row][col];
        } catch (java.lang.IllegalArgumentException e) {
            return false;
        }
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        row--;
        col--;
        checkBoundaries(row, col);
        return uf.find(virtualTop) == uf.find(getFlatMapId(row, col));
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return openSites;
    }

    // does the system percolate?
    public boolean percolates() {
        int top = uf.find(virtualTop);
        int bottom = uf.find(virtualBottom);
        return top == bottom;
    }

    private int getFlatMapId(final int row, final int col) {
        return col + n * row;
    }

    private void checkBoundaries(int row, int col) {
        if (row >= n || col >= n || row < 0 || col < 0) {
            throw new IllegalArgumentException();
        }
    }

    private void grid() {
        for (int i = 0; i < sites[0].length; i++) {
            for (int j = 0; j < sites[1].length; j++) {
                System.out.printf(" %d ", sites[i][j] ? 1 : 0);
            }
            System.out.printf("%n");
        }
        System.out.printf("%n");
    }

    // test client (optional)
    public static void main(String[] args) {
        Percolation percolation = new Percolation(3);
        percolation.open(1, 1);
        percolation.grid();
        System.out.println(percolation.percolates());
        percolation.open(2, 1);
        percolation.grid();
        System.out.println(percolation.percolates());
        percolation.open(3, 1);
        percolation.grid();
        System.out.println(percolation.openSites);
        System.out.println(percolation.percolates());
    }
}